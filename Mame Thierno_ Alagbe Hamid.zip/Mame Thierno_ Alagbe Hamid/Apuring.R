#Preparation des donnèes
library(haven)
library(dplyr)
library(psych)
path = 'G:/Cours R 2023/Projet R/Projet ISEP2 2023/Projet ISEP2 2023/Ressources'
path_10a = paste0(path, '/s10a_me_SEN_2021.dta')
path_10b = paste0(path, '/s10b_me_SEN_2021.dta')
data_10a = read_dta(path_10a)
data_10b = read_dta(path_10b)

View(data_10a)
View(data_10b)

## Starting with the 10b base
data_10b_subset = subset(data_10b, select = c('interview__key', 's10q12a', 's10q16', 's10q17a',
                                              's10q17b', 's10q17c','s10q23', 's10q28', 's10q29', 's10q30', 's10q31', 's10q32',
                                              's10q33', 's10q34', 's10q46', 's10q47', 's10q48', 's10q49', 's10q50', 's10q51',
                                              's10q52', 's10q53', 's10q54', 's10q55', 's10q56', 's10q57'))
## Renaming the variables
new_names_10b = c('interview_key', 'Activity', 'Product', 'Section_Code', 'Branch_Code', 'Activity_Code', 'Activity_local',
                  'Phone_number', 'Accounting', 'Taxation_phone', 'RC_Registered', 'Person_registered', 'Legal_form', 'Finance_source', 'Sold_product', 'Buy_product', 'Profit_product',
                  'Raw_materials_buy', 'Profit_services', 'Other_CI', 'Home_spending', 'Services_fees', 'Other_spending', 'Patente', 'Taxes', 'Admin_fees')

colnames(data_10b_subset) = new_names_10b
View(data_10b_subset)

variables_avant_sold_product = c('interview_key', 'Activity', 'Product', 'Section_Code', 'Branch_Code', 
                                 'Activity_Code', 'Activity_local', 'Phone_number', 'Accounting', 
                                 'Taxation_phone', 'RC_Registered', 'Person_registered', 'Legal_form', 'Finance_source')
variables_apres_sold_product = c('Sold_product', 'Buy_product', 'Profit_product', 'Raw_materials_buy', 
                                 'Profit_services', 'Other_CI', 'Home_spending', 'Services_fees', 
                                 'Other_spending', 'Patente', 'Taxes', 'Admin_fees')

# Remplacer les valeurs manquantes par des chaînes vides pour les variables avant 'Sold_product'
data_10b_subset = data_10b_subset %>% 
  mutate(across(all_of(variables_avant_sold_product), ~ ifelse(is.na(.), "", as.character(.))))

# Remplacer les valeurs manquantes par des zéros pour les variables après 'Sold_product'
data_10b_subset = data_10b_subset %>% 
  mutate(across(all_of(variables_apres_sold_product), ~ ifelse(is.na(.), 0, as.numeric(.))))

View(data_10b_subset)

## Now for the 10a base

data_10a_subset = subset(data_10a, select = c('interview__key', 's10q01', 's10q02', 's10q03', 's10q04', 's10q05',
                                              's10q06', 's10q07', 's10q08', 's10q09', 's10q10'))
new_names_10a = c('interview_key', 's10q01', 's10q02', 's10q03', 's10q04', 's10q05',
                  's10q06', 's10q07', 's10q08', 's10q09', 's10q10')
colnames(data_10a_subset) = new_names_10a
View(data_10a_subset)

## Merging the two dataset

data_10 <- merge(data_10a_subset, data_10b_subset, by = 'interview_key', all.y = TRUE)
View(data_10)

# Traitement des variables

## Nombre de na

na_count = colSums(is.na(data_10))
print(na_count)

##Like we can see with the na_count, there is no NA for the data_10b previous base. But we have some NA values in the 10a base.
## Therefore, we are going to drop these NA values from the data_10 base so that we only got persons who filled the form in the database.

data_10 <- data_10[complete.cases(data_10), ]
View(data_10) ## We now have 3377 lines in our chart. 5 less lines than the previous base. We dropped the NA values
## Let's check the number of NA values

na_count = colSums(is.na(data_10))
print(na_count) ## It's OK

## Verification of the coherence of the data.
## In this case, this work is about seeing if someone filled the 10b data base even though he answered 'No' to all the 10a question

i = 0
error_filling = list()
variables_data_10 = c('s10q02', 's10q03', 's10q04', 's10q05', 's10q06', 's10q07', 's10q08', 's10q09', 's10q10')

for (row in 1:nrow(data_10)) {
  if (all(data_10[row, variables_data_10] == 2) && all(data_10[row, variables_apres_sold_product] != 0)) {
    i = i + 1
    error_filling = c(error_filling, row)
  }
}

print(i)
print(error_filling)

### On voit donc qu'il n'existe pas d'éléments ayant rempli 'Non' à toutes les questions de 10a mais qui a rempli 10b

## Nombre de répondant n'ayant pas d'entreprises

count = 0
if (sum(apply(data_10[, variables_data_10], 1, function(x) all(x == 2))) > 0) {
  count = sum(apply(data_10[, variables_data_10], 1, function(x) all(x == 2)))
}
print(count)

### Il y a donc 961 répondants qui n'ont pas d'entreprises.

## De ce fait la base est tout à fait cohérente.

#Analyse descriptive des variables

## Statistique univariée

vars = c('Section_Code', 'Branch_Code', 'Activity_local', 'Phone_number', 'Accounting', 'Taxation_phone', 'RC_Registered', 'Person_registered', 'Legal_form', 'Finance_source')
for (variable in vars){
  print(variable)
  var_counts = table(data_10[, variable])
  print(var_counts)
  barplot(var_counts, main = "Répartition des entreprises suivant le code de section", 
          xlab = "Code de section", 
          ylab = "Nombre d'entreprises",
          col = "steelblue",  
          border = "white",
          las = 2,
          cex.names = 0.8,
          ylim = c(0, max(var_counts) * 1.2))
}
## Descriptive des variables d'intérêt principales

for (variable in variables_apres_sold_product){
  print(variable)
  print(describe(data_10[ , variable]))
}
## Statistique bivariée

### Building a base for the results
dta_10b_sub = subset(data_10b, select = c('interview__key', 's10q12a', 's10q16', 's10q17a',
                                          's10q17b', 's10q17c','s10q23', 's10q28', 's10q29', 's10q30', 's10q31', 's10q32',
                                          's10q33', 's10q34', 's10q46', 's10q47', 's10q48', 's10q49', 's10q50', 's10q51',
                                          's10q52', 's10q53', 's10q54', 's10q55', 's10q56', 's10q57'))

new_names_10b = c('interview_key', 'Activity', 'Product', 'Section_Code', 'Branch_Code', 'Activity_Code', 'Activity_local',
                  'Phone_number', 'Accounting', 'Taxation_phone', 'RC_Registered', 'Person_registered', 'Legal_form', 'Finance_source', 'Sold_product', 'Buy_product', 'Profit_product',
                  'Raw_materials_buy', 'Profit_services', 'Other_CI', 'Home_spending', 'Services_fees', 'Other_spending', 'Patente', 'Taxes', 'Admin_fees')

colnames(dta_10b_sub) = new_names_10b

dta_10a_sub= subset(data_10a, select = c('interview__key', 's10q01', 's10q02', 's10q03', 's10q04', 's10q05',
                                         's10q06', 's10q07', 's10q08', 's10q09', 's10q10'))
new_names_10a = c('interview_key', 's10q01', 's10q02', 's10q03', 's10q04', 's10q05',
                  's10q06', 's10q07', 's10q08', 's10q09', 's10q10')
colnames(dta_10a_sub) = new_names_10a

dta_10 = merge(dta_10a_sub, dta_10b_sub, by = 'interview_key', all.y = TRUE)

dta_10 = dta_10[complete.cases(dta_10), ]

vars = c('Section_Code', 'Branch_Code', 'Activity_local', 'Phone_number', 'Accounting', 
         'Taxation_phone', 'RC_Registered', 'Person_registered', 'Legal_form', 'Finance_source')
for (var in vars) {
  dta_10[[var]] = as.character(dta_10[[var]])
}

View(dta_10)
### Results

#### Coefficient de corrélation entre toutes les variables d'intérêt principales

cor_matrix = matrix(NA, nrow = length(variables_apres_sold_product), ncol = length(variables_apres_sold_product), 
                    dimnames = list(variables_apres_sold_product, variables_apres_sold_product))

for (i in 1:length(variables_apres_sold_product)) {
  for (j in 1:length(variables_apres_sold_product)) {
    cor_matrix[i, j] = cor(dta_10[[variables_apres_sold_product[i]]], dta_10[[variables_apres_sold_product[j]]])
  }
}

View(cor_matrix)

relation_matrix = matrix("", nrow = length(variables_apres_sold_product), ncol = length(variables_apres_sold_product), 
                    dimnames = list(variables_apres_sold_product, variables_apres_sold_product))
seuil_correlation = 0.87
for (i in 1:length(variables_apres_sold_product)) {
  for (j in 1:length(variables_apres_sold_product)) {
    if (i != j) {
      if (abs(cor_matrix[i, j]) >= seuil_correlation) {
        relation_matrix[i, j] = "Relation"
      } else {
        relation_matrix[i, j] = "Pas de relation"
      }
    } else {
      relation_matrix[i, j] = NA
    }
  }
}

View(relation_matrix)
#### Test ANOVA entre les autres variables d'intérêt:

anova_matrix = matrix(NA, nrow = length(vars), ncol = length(vars), dimnames = list(vars, vars))

for (i in 1:length(vars)) {
  for (j in 1:length(vars)) {
    if (i != j) {
      anova_result = aov(as.formula(paste(vars[i], "~", vars[j])), data = dta_10)
      p_value = summary(anova_result)[[1]][["Pr(>F)"]][1]
      anova_matrix[i, j] = ifelse(p_value < 0.05, "Relation", "Pas de relation")
    } else {
      anova_matrix[i, j] = NA
    }
  }
}

View(anova_matrix)

#### Relation entre les variables d'intérêt principales et les autres variables d'intérêt:

association_matrix = matrix(NA, nrow = length(vars), ncol = length(variables_apres_sold_product), 
                          dimnames = list(vars, variables_apres_sold_product))
for (i in 1:length(vars)) {
  for (j in 1:length(variables_apres_sold_product)) {
    contingency_table = table(dta_10[[vars[i]]], dta_10[[variables_apres_sold_product[j]]])
    association_test = chisq.test(contingency_table)
    p_value = association_test$p.value
    if (p_value < 0.05) {
      association_matrix[i, j] = "Association"
    } else {
      association_matrix[i, j] = "Pas d'association"
    }
  }
}

View(association_matrix)

## Creating Revenu variable
c('Sold_product', 'Buy_product', 'Profit_product', 'Raw_materials_buy', 'Profit_services', 'Other_CI', 'Home_spending', 'Services_fees', 'Other_spending', 'Patente', 'Taxes', 'Admin_fees')

data_10$Revenu_Non_agricole = data_10$Sold_product - data_10$Buy_product + data_10$Profit_product - data_10$Raw_materials_buy +
  data_10$Profit_services - data_10$Other_CI - data_10$Home_spending - data_10$Services_fees -data_10$Other_spending - 
  data_10$Patente - data_10$Taxes - data_10$Admin_fees

View(data_10)


## Statistiques descriptives sur la variable revenu

describe(data_10$Revenu_Non_agricole)

which.min(data_10$Revenu_Non_agricole)
View(data_10[which.min(data_10$Revenu_Non_agricole), ])

## Revenu par ménage

Revenu_menage = aggregate(Revenu_Non_agricole ~ interview_key, data = data_10, FUN = sum)
Revenu_menage

base_revenu_menage = data.frame(
  interview_key = unique(Revenu_menage$interview_key),
  Revenu_par_menage = Revenu_menage$Revenu_Non_agricole
)
View(base_revenu_menage)


## Revenu non agricole

Revenu_non_agricole = sum(data_10$Revenu_Non_agricole)
print(Revenu_non_agricole)